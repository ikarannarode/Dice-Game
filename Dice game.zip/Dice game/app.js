const draw = new Audio('Assets/draw.wav');
const winner = new Audio('Assets/winner.wav');
const sound = new Audio('Assets/sound.mp3');
const imgs = ['dice1.png', 'dice2.png', 'dice3.png', 'dice4.png', 'dice5.png', 'dice6.png'];
var button = document.getElementById('btn');
button.addEventListener("click", Play);
function Play() {

    var indexf = Math.floor(Math.random() * 6) + 0;
    var indexs = Math.floor(Math.random() * 6) + 0;
    if (indexf > indexs) {
        document.getElementById('head-txt').innerHTML = "🚩 Player 1 is winner";
        winner.play();
    }
    else if (indexf == indexs) {
        document.getElementById('head-txt').innerHTML = "Draw Play Again !";
        draw.play();

    }
    else if(indexf < indexs){
        document.getElementById('head-txt').innerHTML = "🚩 Player 2 is winner";
        winner.play();
    }
    var img1 = document.getElementById('img1');
    var img2 = document.getElementById('img2');
    img1.src = "Assets/" + imgs[indexf];
    img2.src = "Assets/" + imgs[indexs];
    sound.play();
}